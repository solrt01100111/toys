#Timer
#Need to change to current working directory with sound file to work.

import time
from playsound import playsound
import os

while True:
    try: 
        hours = int(input('Hours: '))
    except: 
        print('Invalid input. Enter an integer.')
    else:
        break
while True:
    try: 
        minutes = int(input('Minutes: '))
    except: 
        print('Invalid input. Enter an integer.')
    else:
        break
while True:
    try: 
        seconds = int(input('Seconds: '))
    except: 
        print('Invalid input. Enter an integer.')
    else:
        break
   
        

time_remaining = hours * 3600 + minutes * 60 + seconds


 
def timer(time_remaining):
    while time_remaining > 0:
        time.sleep(1)
        time_remaining -= 1
       
        left_hours = round((time_remaining - time_remaining%3600)/3600,0)
        left_minutes = round((time_remaining - left_hours*3600)/60 - (time_remaining - left_hours*3600)%60/60,0)
        left_seconds = round((time_remaining - left_hours*3600 - left_minutes*60),0)
        print(f'H: {str(left_hours)} M: {left_minutes} S: {left_seconds}')
        print(f'Time Remaining in Seconds: {time_remaining}')

filepath = os.getcwd()+'/'+'mixkit-sound-alert-in-hall-1006.wav'
timer(time_remaining)
print(filepath)
playsound(filepath)


 